# بناء تطبيق سوقنا Android

## أسهل طريقة

ارفع مجلد المشروع إلى GitHub، ثم:

1. افتح تبويب **Actions**.
2. اختر **Build Souqna Android APK**.
3. اضغط **Run workflow**.
4. إذا كان Supabase جاهزًا، أدخل:
   - Supabase Project URL
   - Supabase anon public key
5. بعد انتهاء البناء افتح الـ workflow ثم **Artifacts** وحمّل `souqna-android-release`.

## ملاحظة

الـ anon public key يمكن استخدامه داخل تطبيق Flutter. لا تضع Service Role Key داخل التطبيق.

إذا لم تدخل بيانات Supabase، سيُبنى التطبيق، لكن وظائف Supabase لن تعمل حتى يتم تزويده بالقيم الصحيحة.
