import 'package:supabase_flutter/supabase_flutter.dart';

/// إعدادات الاتصال بـ Supabase
/// هتلاقي القيم دي في لوحة تحكم مشروعك على supabase.com:
/// Project Settings > API
class SupabaseConfig {
  // TODO: استبدل القيمتين دول ببيانات مشروعك الحقيقية
  static const String url = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://YOUR_PROJECT_ID.supabase.co',
  );
  static const String anonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'YOUR_ANON_PUBLIC_KEY',
  );
}

class SupabaseService {
  SupabaseService._();

  static Future<void> init() async {
    await Supabase.initialize(
      url: SupabaseConfig.url,
      anonKey: SupabaseConfig.anonKey,
    );
  }

  static SupabaseClient get client => Supabase.instance.client;
}
