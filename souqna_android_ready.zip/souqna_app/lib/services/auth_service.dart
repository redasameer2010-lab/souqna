import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_service.dart';

class AuthService {
  AuthService._();

  static SupabaseClient get _client => SupabaseService.client;

  static User? get currentUser => _client.auth.currentUser;

  static Future<void> signUp({
    required String email,
    required String password,
    required String fullName,
    required String role, // 'customer' | 'merchant' | 'marketer' | 'courier'
    String? phone,
  }) async {
    await _client.auth.signUp(
      email: email,
      password: password,
      data: {
        'full_name': fullName,
        'role': role,
        'phone': phone,
      },
    );
  }

  static Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await _client.auth.signInWithPassword(email: email, password: password);
  }

  static Future<void> signOut() async {
    await _client.auth.signOut();
  }

  /// يقرأ دور المستخدم الحالي من جدول profiles
  static Future<String?> getCurrentUserRole() async {
    final user = currentUser;
    if (user == null) return null;
    final response = await _client
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .maybeSingle();
    return response?['role'] as String?;
  }
}
