import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ألوان الهوية البصرية لتطبيق "سوقنا"
/// مستنتجة تقريبيًا من الموقع الحالي sauqna.com
class AppColors {
  AppColors._();

  // اللون الأساسي - تركواز
  static const Color primary = Color(0xFF1A9E9E);
  static const Color primaryDark = Color(0xFF0F6E56);

  // الكحلي الغامق - العناوين
  static const Color navy = Color(0xFF1B2A4A);

  // الذهبي - عنصر مساعد
  static const Color gold = Color(0xFFC99A45);

  // خلفيات فاتحة (تدرج تركواز)
  static const Color bgLight = Color(0xFFE4F5F3);
  static const Color bgLighter = Color(0xFFF5FBFA);

  static const Color white = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF4A5568);

  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [bgLight, bgLighter],
  );
}

class AppTheme {
  AppTheme._();

  static ThemeData get light {
    final baseTextTheme = GoogleFonts.cairoTextTheme();

    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.white,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        primary: AppColors.primary,
        secondary: AppColors.gold,
      ),
      textTheme: baseTextTheme.apply(
        bodyColor: AppColors.navy,
        displayColor: AppColors.navy,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.white,
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: GoogleFonts.cairo(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
