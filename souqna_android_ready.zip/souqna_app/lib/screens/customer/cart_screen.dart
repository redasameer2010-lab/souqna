import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/cart_service.dart';
import '../../services/supabase_service.dart';
import '../../services/auth_service.dart';
import 'order_confirmation_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _addressController = TextEditingController();
  String? _error;
  bool _placing = false;

  Future<void> _placeOrder() async {
    if (_addressController.text.trim().isEmpty) {
      setState(() => _error = 'من فضلك أدخل عنوان التوصيل');
      return;
    }
    final customerId = AuthService.currentUser?.id;
    if (customerId == null) {
      setState(() => _error = 'لازم تسجل دخول عشان تكمل الطلب');
      return;
    }
    final items = CartService.instance.items.value;
    if (items.isEmpty) return;

    setState(() {
      _placing = true;
      _error = null;
    });

    try {
      final client = SupabaseService.client;

      // 1) إنشاء الطلب
      final orderRow = await client
          .from('orders')
          .insert({
            'customer_id': customerId,
            'address': _addressController.text.trim(),
            'total': CartService.instance.total,
            'status': 'pending',
          })
          .select()
          .single();

      final orderId = orderRow['id'] as String;

      // 2) إضافة عناصر الطلب
      final itemsPayload = items
          .map((item) => {
                'order_id': orderId,
                'product_id': item.product.id,
                'quantity': item.quantity,
                'sell_price': item.sellPrice,
              })
          .toList();

      await client.from('order_items').insert(itemsPayload);

      if (!mounted) return;
      CartService.instance.clear();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const OrderConfirmationScreen()),
      );
    } catch (e) {
      setState(() => _error = 'حصل خطأ أثناء إتمام الطلب، حاول تاني');
    } finally {
      if (mounted) setState(() => _placing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('السلة')),
      body: ValueListenableBuilder(
        valueListenable: CartService.instance.items,
        builder: (context, items, _) {
          if (items.isEmpty) {
            return const Center(
              child: Text('السلة فارغة', style: TextStyle(color: AppColors.textSecondary)),
            );
          }
          return Column(
            children: [
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.bgLight, width: 2),
                      ),
                      child: Row(
                        children: [
                          Text(item.product.imageEmoji, style: const TextStyle(fontSize: 32)),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.product.name,
                                    style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
                                Text('الكمية: ${item.quantity}',
                                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                              ],
                            ),
                          ),
                          Text('${item.total.toStringAsFixed(0)} ر.س',
                              style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary)),
                          IconButton(
                            icon: const Icon(Icons.close, size: 18),
                            onPressed: () => CartService.instance.removeAt(index),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Align(
                      alignment: Alignment.centerRight,
                      child: Text('عنوان التوصيل', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      controller: _addressController,
                      decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'الحي، الشارع، رقم المبنى'),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 8),
                      Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13)),
                    ],
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('الإجمالي', style: TextStyle(fontSize: 16, color: AppColors.navy)),
                        Text('${CartService.instance.total.toStringAsFixed(0)} ر.س',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.primary)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _placing ? null : _placeOrder,
                        child: _placing
                            ? const SizedBox(
                                width: 20, height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Text('إتمام الطلب (الدفع عند الاستلام)'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
