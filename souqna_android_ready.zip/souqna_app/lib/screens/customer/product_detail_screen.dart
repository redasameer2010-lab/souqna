import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/product.dart';
import '../../services/cart_service.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(product.name)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 180,
                height: 180,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.bgLight,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(product.imageEmoji, style: const TextStyle(fontSize: 72)),
              ),
            ),
            const SizedBox(height: 24),
            Text(product.category,
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            Text(product.name,
                style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.navy)),
            const SizedBox(height: 10),
            Text('${product.basePrice.toStringAsFixed(0)} ر.س',
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.primary)),
            const SizedBox(height: 6),
            Text('متوفر: ${product.stock} قطعة',
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  CartService.instance.add(product);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تمت الإضافة إلى السلة')),
                  );
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const CartScreen()));
                },
                child: const Text('أضف إلى السلة'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
