import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/supabase_service.dart';
import '../../services/auth_service.dart';

class OrderDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> order;
  const OrderDetailsScreen({super.key, required this.order});

  @override
  State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {
  bool _loading = false;
  String? _error;

  Future<void> _confirmDelivery() async {
    final courierId = AuthService.currentUser?.id;
    if (courierId == null) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final client = SupabaseService.client;
      final orderId = widget.order['id'] as String;

      // استلام الطلب وتحديث حالته لتم التوصيل
      await client.from('orders').update({
        'courier_id': courierId,
        'status': 'delivered',
      }).eq('id', orderId);

      // لو الطلب جاي من رابط مسوق، سجّل العمولة تلقائيًا
      final marketerId = widget.order['marketer_id'] as String?;
      if (marketerId != null) {
        final items = (widget.order['order_items'] as List?) ?? [];
        double commission = 0;
        for (final item in items) {
          final product = item['products'] as Map<String, dynamic>?;
          final sellPrice = (item['sell_price'] as num).toDouble();
          final basePrice = (product?['base_price'] as num?)?.toDouble() ?? sellPrice;
          final qty = (item['quantity'] as num).toInt();
          commission += (sellPrice - basePrice) * qty;
        }
        if (commission > 0) {
          await client.from('commissions').insert({
            'marketer_id': marketerId,
            'order_id': orderId,
            'amount': commission,
          });
        }
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تأكيد التسليم والتحصيل')),
      );
      Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'حصل خطأ أثناء التأكيد، حاول تاني');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final order = widget.order;
    final items = (order['order_items'] as List?) ?? [];
    final orderId = order['id'] as String;

    return Scaffold(
      appBar: AppBar(title: Text('طلب #${orderId.substring(0, 8)}')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('العنوان', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 4),
            Text(order['address'] as String,
                style: const TextStyle(color: AppColors.navy, fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 20),
            const Text('محتويات الطلب', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
            const SizedBox(height: 8),
            ...items.map((item) {
              final product = item['products'] as Map<String, dynamic>?;
              final name = product?['name'] as String? ?? 'منتج';
              final qty = item['quantity'] as num;
              final sellPrice = (item['sell_price'] as num).toDouble();
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('$name × ${qty.toInt()}'),
                    Text('${(sellPrice * qty).toStringAsFixed(0)} ر.س'),
                  ],
                ),
              );
            }),
            const Divider(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('المبلغ المطلوب تحصيله', style: TextStyle(color: AppColors.navy)),
                Text('${(order['total'] as num).toStringAsFixed(0)} ر.س',
                    style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 18)),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13)),
            ],
            const Spacer(),
            if (order['status'] != 'delivered')
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _confirmDelivery,
                  child: _loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('تأكيد التسليم والتحصيل'),
                ),
              )
            else
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('تم تسليم هذا الطلب بالفعل',
                    textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary)),
              ),
          ],
        ),
      ),
    );
  }
}
