import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/product.dart';

class SelectProductScreen extends StatefulWidget {
  final Product product;
  const SelectProductScreen({super.key, required this.product});

  @override
  State<SelectProductScreen> createState() => _SelectProductScreenState();
}

class _SelectProductScreenState extends State<SelectProductScreen> {
  late double _sellPrice;

  @override
  void initState() {
    super.initState();
    _sellPrice = widget.product.basePrice;
  }

  double get _commission => _sellPrice - widget.product.basePrice;

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Scaffold(
      appBar: AppBar(title: Text(p.name)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('سعر التاجر الأساسي: ${p.basePrice.toStringAsFixed(0)} ر.س',
                style: const TextStyle(color: AppColors.textSecondary)),
            Text('أقصى سعر بيع مسموح: ${p.maxSuggestedPrice.toStringAsFixed(0)} ر.س',
                style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 24),
            const Text('حدد سعر البيع', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
            Slider(
              value: _sellPrice,
              min: p.basePrice,
              max: p.maxSuggestedPrice,
              activeColor: AppColors.primary,
              label: _sellPrice.toStringAsFixed(0),
              onChanged: (v) => setState(() => _sellPrice = v),
            ),
            Center(
              child: Text('${_sellPrice.toStringAsFixed(0)} ر.س',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.primary)),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.bgLight,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('عمولتك المتوقعة', style: TextStyle(color: AppColors.navy)),
                  Text('${_commission.toStringAsFixed(0)} ر.س',
                      style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.gold)),
                ],
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تم إنشاء رابط المنتج (نسخة تجريبية)')),
                  );
                  Navigator.pop(context);
                },
                child: const Text('إنشاء رابط للمشاركة'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
