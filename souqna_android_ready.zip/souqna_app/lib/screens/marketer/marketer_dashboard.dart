import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../models/product.dart';
import '../../services/supabase_service.dart';
import '../../services/auth_service.dart';
import 'select_product_screen.dart';

class MarketerDashboard extends StatefulWidget {
  const MarketerDashboard({super.key});

  @override
  State<MarketerDashboard> createState() => _MarketerDashboardState();
}

class _MarketerDashboardState extends State<MarketerDashboard> {
  late Future<Map<String, dynamic>> _dataFuture;

  @override
  void initState() {
    super.initState();
    _dataFuture = _fetchData();
  }

  Future<Map<String, dynamic>> _fetchData() async {
    final marketerId = AuthService.currentUser?.id;
    final client = SupabaseService.client;

    final productRows = await client
        .from('products')
        .select()
        .eq('is_active', true)
        .order('created_at', ascending: false);

    final products = (productRows as List).map((row) {
      return Product(
        id: row['id'] as String,
        name: row['name'] as String,
        category: (row['category'] as String?) ?? '',
        basePrice: (row['base_price'] as num).toDouble(),
        maxSuggestedPrice: (row['max_suggested_price'] as num).toDouble(),
        imageEmoji: '🛍️',
        stock: (row['stock'] as num).toInt(),
      );
    }).toList();

    final commissionRows = await client
        .from('commissions')
        .select('amount')
        .eq('marketer_id', marketerId as Object);

    final totalCommission = (commissionRows as List)
        .fold<double>(0, (sum, row) => sum + (row['amount'] as num).toDouble());

    return {'products': products, 'totalCommission': totalCommission};
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة المسوق')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _dataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('تعذر تحميل البيانات، تأكد من إعدادات Supabase',
                    textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary)),
              ),
            );
          }
          final products = snapshot.data?['products'] as List<Product>? ?? [];
          final totalCommission = snapshot.data?['totalCommission'] as double? ?? 0;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('إجمالي العمولات', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    const SizedBox(height: 6),
                    Text('${totalCommission.toStringAsFixed(0)} ر.س',
                        style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text('منتجات متاحة للتسويق',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.navy)),
              const SizedBox(height: 8),
              if (products.isEmpty)
                const Text('لا توجد منتجات متاحة حاليًا', style: TextStyle(color: AppColors.textSecondary)),
              ...products.map((p) => Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.bgLight, width: 2),
                    ),
                    child: Row(
                      children: [
                        Text(p.imageEmoji, style: const TextStyle(fontSize: 28)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
                              Text('سعر التاجر: ${p.basePrice.toStringAsFixed(0)} ر.س',
                                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                            ],
                          ),
                        ),
                        TextButton(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => SelectProductScreen(product: p)),
                          ),
                          child: const Text('حدد سعرك'),
                        ),
                      ],
                    ),
                  )),
            ],
          );
        },
      ),
    );
  }
}
