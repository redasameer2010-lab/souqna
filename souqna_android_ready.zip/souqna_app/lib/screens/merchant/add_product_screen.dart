import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/supabase_service.dart';
import '../../services/auth_service.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _nameController = TextEditingController();
  final _categoryController = TextEditingController();
  final _priceController = TextEditingController();
  final _maxPriceController = TextEditingController();
  final _stockController = TextEditingController();
  String? _error;
  bool _loading = false;

  Future<void> _submit() async {
    if (_nameController.text.trim().isEmpty ||
        _priceController.text.trim().isEmpty ||
        _maxPriceController.text.trim().isEmpty ||
        _stockController.text.trim().isEmpty) {
      setState(() => _error = 'من فضلك املأ كل الحقول المطلوبة');
      return;
    }

    final basePrice = double.tryParse(_priceController.text.trim());
    final maxPrice = double.tryParse(_maxPriceController.text.trim());
    final stock = int.tryParse(_stockController.text.trim());

    if (basePrice == null || maxPrice == null || stock == null) {
      setState(() => _error = 'تأكد إن الأسعار والكمية أرقام صحيحة');
      return;
    }
    if (maxPrice < basePrice) {
      setState(() => _error = 'أقصى سعر بيع لازم يكون أكبر من أو يساوي السعر الأساسي');
      return;
    }

    final merchantId = AuthService.currentUser?.id;
    if (merchantId == null) {
      setState(() => _error = 'لازم تسجل دخول كتاجر الأول');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      await SupabaseService.client.from('products').insert({
        'merchant_id': merchantId,
        'name': _nameController.text.trim(),
        'category': _categoryController.text.trim(),
        'base_price': basePrice,
        'max_suggested_price': maxPrice,
        'stock': stock,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت إضافة المنتج بنجاح')),
      );
      Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'حصل خطأ أثناء الحفظ، حاول تاني');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة منتج جديد')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('اسم المنتج', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            TextField(controller: _nameController, decoration: const InputDecoration(border: OutlineInputBorder())),
            const SizedBox(height: 16),
            const Text('التصنيف', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            TextField(controller: _categoryController, decoration: const InputDecoration(border: OutlineInputBorder())),
            const SizedBox(height: 16),
            const Text('السعر الأساسي (ر.س)', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            TextField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            const Text('أقصى سعر بيع مسموح للمسوق (ر.س)', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            TextField(
              controller: _maxPriceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            const Text('الكمية بالمخزون', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            TextField(
              controller: _stockController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 13)),
            ],
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loading ? null : _submit,
              child: _loading
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('حفظ المنتج'),
            ),
          ],
        ),
      ),
    );
  }
}
