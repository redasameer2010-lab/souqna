import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../services/supabase_service.dart';
import '../../services/auth_service.dart';
import 'add_product_screen.dart';

class MerchantDashboard extends StatefulWidget {
  const MerchantDashboard({super.key});

  @override
  State<MerchantDashboard> createState() => _MerchantDashboardState();
}

class _MerchantDashboardState extends State<MerchantDashboard> {
  late Future<Map<String, dynamic>> _dataFuture;

  @override
  void initState() {
    super.initState();
    _dataFuture = _fetchData();
  }

  Future<Map<String, dynamic>> _fetchData() async {
    final merchantId = AuthService.currentUser?.id;
    final client = SupabaseService.client;

    final products = await client
        .from('products')
        .select()
        .eq('merchant_id', merchantId as Object)
        .order('created_at', ascending: false);

    // الطلبات اللي فيها منتجات التاجر ده (بحسب سياسة RLS)
    final orders = await client
        .from('orders')
        .select('id, total, status, address')
        .order('created_at', ascending: false);

    return {'products': products as List, 'orders': orders as List};
  }

  void _refresh() {
    setState(() => _dataFuture = _fetchData());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التاجر')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
              context, MaterialPageRoute(builder: (_) => const AddProductScreen()));
          _refresh();
        },
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add),
        label: const Text('إضافة منتج'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _dataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('تعذر تحميل البيانات، تأكد من إعدادات Supabase',
                    textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary)),
              ),
            );
          }
          final products = snapshot.data?['products'] as List? ?? [];
          final orders = snapshot.data?['orders'] as List? ?? [];

          return RefreshIndicator(
            onRefresh: () async => _refresh(),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _SectionTitle('منتجاتي (${products.length})'),
                const SizedBox(height: 8),
                if (products.isEmpty)
                  const Text('لسه مافيش منتجات، ابدأ بإضافة أول منتج',
                      style: TextStyle(color: AppColors.textSecondary)),
                ...products.map((p) => Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.bgLight, width: 2),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.inventory_2_outlined, color: AppColors.primary),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(p['name'] as String,
                                    style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
                                Text('المخزون: ${p['stock']}',
                                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                              ],
                            ),
                          ),
                          Text('${(p['base_price'] as num).toStringAsFixed(0)} ر.س',
                              style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary)),
                        ],
                      ),
                    )),
                const SizedBox(height: 20),
                _SectionTitle('الطلبات الواردة (${orders.length})'),
                const SizedBox(height: 8),
                if (orders.isEmpty)
                  const Text('لسه مافيش طلبات', style: TextStyle(color: AppColors.textSecondary)),
                ...orders.map((o) => Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.bgLight, width: 2),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(o['address'] as String,
                                    maxLines: 1, overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.navy)),
                                Text(_statusLabel(o['status'] as String),
                                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                              ],
                            ),
                          ),
                          Text('${(o['total'] as num).toStringAsFixed(0)} ر.س',
                              style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                        ],
                      ),
                    )),
              ],
            ),
          );
        },
      ),
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'pending':
        return 'بانتظار الاستلام';
      case 'preparing':
        return 'قيد التجهيز';
      case 'out_for_delivery':
        return 'في الطريق';
      case 'delivered':
        return 'تم التوصيل';
      default:
        return status;
    }
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.navy));
  }
}
