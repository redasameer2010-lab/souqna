-- =========================================================
-- سوقنا (Souqna) - مخطط قاعدة البيانات على Supabase
-- شغّل الملف ده كامل من داخل Supabase SQL Editor
-- =========================================================

-- نوع الأدوار المتاحة في النظام
create type user_role as enum ('customer', 'merchant', 'marketer', 'courier');

-- حالة الطلب
create type order_status as enum ('pending', 'preparing', 'out_for_delivery', 'delivered', 'cancelled');

-- =========================================================
-- 1) الملفات الشخصية (مرتبطة تلقائيًا بجدول auth.users)
-- =========================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role user_role not null,
  city text,
  created_at timestamptz not null default now()
);

-- تفعيل RLS
alter table public.profiles enable row level security;

-- كل مستخدم يقدر يشوف ويعدل بروفايله بس
create policy "المستخدم يشوف بروفايله"
  on public.profiles for select
  using (auth.uid() = id);

create policy "المستخدم يعدل بروفايله"
  on public.profiles for update
  using (auth.uid() = id);

-- =========================================================
-- 2) المنتجات (يضيفها التاجر)
-- =========================================================
create table public.products (
  id uuid primary key default gen_random_uuid(),
  merchant_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  category text,
  base_price numeric(10,2) not null check (base_price >= 0),
  max_suggested_price numeric(10,2) not null check (max_suggested_price >= base_price),
  stock int not null default 0 check (stock >= 0),
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

-- الكل يقدر يشوف المنتجات الفعالة (للعملاء والمسوقين)
create policy "الجميع يشوف المنتجات الفعالة"
  on public.products for select
  using (is_active = true);

-- التاجر بس يقدر يضيف/يعدل منتجاته
create policy "التاجر يضيف منتج"
  on public.products for insert
  with check (auth.uid() = merchant_id);

create policy "التاجر يعدل منتجاته"
  on public.products for update
  using (auth.uid() = merchant_id);

-- =========================================================
-- 3) الطلبات
-- =========================================================
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  courier_id uuid references public.profiles(id),
  marketer_id uuid references public.profiles(id), -- لو الطلب جه من رابط مسوق
  status order_status not null default 'pending',
  address text not null,
  total numeric(10,2) not null default 0,
  created_at timestamptz not null default now()
);

alter table public.orders enable row level security;

-- العميل يشوف طلباته بس
create policy "العميل يشوف طلباته"
  on public.orders for select
  using (auth.uid() = customer_id);

-- العميل ينشئ طلب باسمه
create policy "العميل ينشئ طلب"
  on public.orders for insert
  with check (auth.uid() = customer_id);

-- المندوب يشوف الطلبات المخصصة له
create policy "المندوب يشوف طلباته"
  on public.orders for select
  using (auth.uid() = courier_id);

-- المندوب يحدّث حالة الطلب المخصص له
create policy "المندوب يحدّث حالة التوصيل"
  on public.orders for update
  using (auth.uid() = courier_id);

-- المسوق يشوف الطلبات اللي جاية من روابطه (للعمولة)
create policy "المسوق يشوف طلبات عمولته"
  on public.orders for select
  using (auth.uid() = marketer_id);

-- المندوب يشوف الطلبات المعلّقة اللي لسه محدش استلمها (عشان يقدر يختار طلب)
create policy "المندوب يشوف الطلبات المعلقة"
  on public.orders for select
  using (
    status = 'pending'
    and exists (select 1 from public.profiles pr where pr.id = auth.uid() and pr.role = 'courier')
  );

-- المندوب يقدر يستلم طلب معلّق (يحجزه لنفسه)
create policy "المندوب يستلم طلب"
  on public.orders for update
  using (
    exists (select 1 from public.profiles pr where pr.id = auth.uid() and pr.role = 'courier')
    and (courier_id is null or courier_id = auth.uid())
  );

-- التاجر يشوف الطلبات اللي فيها منتجاته (عبر order_items)
create policy "التاجر يشوف الطلبات اللي فيها منتجاته"
  on public.orders for select
  using (
    exists (
      select 1 from public.order_items oi
      join public.products p on p.id = oi.product_id
      where oi.order_id = orders.id and p.merchant_id = auth.uid()
    )
  );

-- =========================================================
-- 4) عناصر الطلب (المنتجات جوه كل طلب)
-- =========================================================
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity int not null check (quantity > 0),
  sell_price numeric(10,2) not null -- السعر اللي اتباع بيه (ممكن يكون سعر مسوق)
);

alter table public.order_items enable row level security;

create policy "أطراف الطلب يشوفوا عناصره"
  on public.order_items for select
  using (
    exists (
      select 1 from public.orders o
      where o.id = order_id
        and (o.customer_id = auth.uid() or o.courier_id = auth.uid() or o.marketer_id = auth.uid())
    )
  );

create policy "العميل يضيف عناصر لطلبه"
  on public.order_items for insert
  with check (
    exists (
      select 1 from public.orders o
      where o.id = order_id and o.customer_id = auth.uid()
    )
  );

create policy "التاجر يشوف order_items لمنتجاته"
  on public.order_items for select
  using (
    exists (
      select 1 from public.products p
      where p.id = product_id and p.merchant_id = auth.uid()
    )
  );

-- =========================================================
-- 5) عمولات المسوق (تُحسب تلقائيًا لما يتسلّم الطلب)
-- =========================================================
create table public.commissions (
  id uuid primary key default gen_random_uuid(),
  marketer_id uuid not null references public.profiles(id),
  order_id uuid not null references public.orders(id),
  amount numeric(10,2) not null,
  created_at timestamptz not null default now()
);

alter table public.commissions enable row level security;

create policy "المسوق يشوف عمولاته"
  on public.commissions for select
  using (auth.uid() = marketer_id);

create policy "المندوب يسجل عمولة عند التسليم"
  on public.commissions for insert
  with check (
    exists (
      select 1 from public.orders o
      where o.id = order_id and o.courier_id = auth.uid()
    )
  );

-- =========================================================
-- 6) Trigger: إنشاء بروفايل تلقائي بعد التسجيل
-- بياخد role و full_name من بيانات التسجيل (raw_user_meta_data)
-- =========================================================
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, role, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'مستخدم جديد'),
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'customer'),
    new.raw_user_meta_data->>'phone'
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
